$(document).ready(function(e){
	$("#botao1 a").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$("#conteudo").load(href + "#conteudo");
	});
});
